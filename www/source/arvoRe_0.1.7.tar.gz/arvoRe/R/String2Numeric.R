String2Numeric <-
function(s) {
	ans <- exec.text(s)
	return(ans)
}

