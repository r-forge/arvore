carregaTclpath <-
function() {
	addTclPath("C:/Tcl/lib")
	addTclPath("C:/Arquivos de programas/Tcl/lib")	
}

