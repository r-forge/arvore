naoimplementado <-
function() {
	require(tcltk)
	Mensagem.txt <- "Esta funcionalidade n�o foi implementada ainda. Desculpe-nos."
	tkmessageBox(message=Mensagem.txt, icon="warning", type="ok", title = "Markov - Custo Efetividade")
	tkfocus(tt)
}

